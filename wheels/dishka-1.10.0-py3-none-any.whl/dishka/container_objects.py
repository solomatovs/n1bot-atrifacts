from abc import abstractmethod
from collections.abc import AsyncGenerator, Awaitable, Callable, Generator
from typing import Any, Protocol, TypeAlias

from dishka.entities.key import CompilationKey

Exit: TypeAlias = tuple[
    Generator[Any, Any, Any] | None,
    AsyncGenerator[Any, Any] | None,
]


class CompiledFactory(Protocol):
    @abstractmethod
    def __call__(
            self,
            getter: Callable[[CompilationKey], Any] | None,
            exits: list[Exit],
            cache: Any,
            context: Any,
            container: Any,
            has: Callable[[CompilationKey], bool | Awaitable[bool]],
    ) -> Any:
        raise NotImplementedError
