# This file auto generated!
# DO NOT EDIT MANUALLY!

version: str = "1.10.0"
__version__: str = "1.10.0"

commit_hash: str = "None"
version_timestamp: str = "2026-04-18 21:26:47.768191+00:00"

tag: str = "1.10.0"
branch: str = "None"
commit_date: str = "None"
commit_count_since_tag: int = 0
