class FastTextModelNotFoundException(Exception):
    pass
