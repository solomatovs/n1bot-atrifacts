# Copyright The OpenTelemetry Authors
# SPDX-License-Identifier: Apache-2.0

from enum import Enum


class Schemas(Enum):
    V1_21_0 = "https://opentelemetry.io/schemas/1.21.0"
    """
    The URL of the OpenTelemetry schema version 1.21.0.
    """

    V1_23_1 = "https://opentelemetry.io/schemas/1.23.1"
    """
    The URL of the OpenTelemetry schema version 1.23.1.
    """

    V1_25_0 = "https://opentelemetry.io/schemas/1.25.0"
    """
    The URL of the OpenTelemetry schema version 1.25.0.
    """

    V1_26_0 = "https://opentelemetry.io/schemas/1.26.0"
    """
    The URL of the OpenTelemetry schema version 1.26.0.
    """

    V1_27_0 = "https://opentelemetry.io/schemas/1.27.0"
    """
    The URL of the OpenTelemetry schema version 1.27.0.
    """

    V1_28_0 = "https://opentelemetry.io/schemas/1.28.0"
    """
    The URL of the OpenTelemetry schema version 1.28.0.
    """

    V1_29_0 = "https://opentelemetry.io/schemas/1.29.0"
    """
    The URL of the OpenTelemetry schema version 1.29.0.
    """

    V1_30_0 = "https://opentelemetry.io/schemas/1.30.0"
    """
    The URL of the OpenTelemetry schema version 1.30.0.
    """

    V1_31_0 = "https://opentelemetry.io/schemas/1.31.0"
    """
    The URL of the OpenTelemetry schema version 1.31.0.
    """

    V1_32_0 = "https://opentelemetry.io/schemas/1.32.0"
    """
    The URL of the OpenTelemetry schema version 1.32.0.
    """

    V1_33_0 = "https://opentelemetry.io/schemas/1.33.0"
    """
    The URL of the OpenTelemetry schema version 1.33.0.
    """

    V1_34_0 = "https://opentelemetry.io/schemas/1.34.0"
    """
    The URL of the OpenTelemetry schema version 1.34.0.
    """
    V1_36_0 = "https://opentelemetry.io/schemas/1.36.0"
    """
    The URL of the OpenTelemetry schema version 1.36.0.
    """

    V1_37_0 = "https://opentelemetry.io/schemas/1.37.0"
    """
    The URL of the OpenTelemetry schema version 1.37.0.
    """

    V1_38_0 = "https://opentelemetry.io/schemas/1.38.0"
    """
    The URL of the OpenTelemetry schema version 1.38.0.
    """

    V1_39_0 = "https://opentelemetry.io/schemas/1.39.0"
    """
    The URL of the OpenTelemetry schema version 1.39.0.
    """

    V1_40_0 = "https://opentelemetry.io/schemas/1.40.0"
    """
    The URL of the OpenTelemetry schema version 1.40.0.
    """

    V1_41_0 = "https://opentelemetry.io/schemas/1.41.0"
    """
    The URL of the OpenTelemetry schema version 1.41.0.
    """

    V1_41_1 = "https://opentelemetry.io/schemas/1.41.1"
    """
    The URL of the OpenTelemetry schema version 1.41.1.
    """

    # when generating new semantic conventions,
    # make sure to add new versions version here.
