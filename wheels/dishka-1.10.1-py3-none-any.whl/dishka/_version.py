# This file auto generated!
# DO NOT EDIT MANUALLY!

version: str = "1.10.1"
__version__: str = "1.10.1"

commit_hash: str = "None"
version_timestamp: str = "2026-04-25 12:07:40.055387+00:00"

tag: str = "1.10.1"
branch: str = "None"
commit_date: str = "None"
commit_count_since_tag: int = 0
