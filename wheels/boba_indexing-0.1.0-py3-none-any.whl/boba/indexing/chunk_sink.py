"""
ChunkSink[T] - потребитель Chunk[T] в pipeline
кладёт чанки в backend (с возможной буферизацией) и flush по команде

Отделяет pipeline-лимиты (batching, transactional flush) от чистой логики
хранения VectorStore[T].

Зачем отдельная абстракция? Несколько причин:

1. Заменяемая терминальная стадия:
    - VectorStoreChunkSink - делегирует raw батч-upsert в VectorStoreWriter[T]
      (без idempotency-check'а; это «голая запись», не reconcile)
    - LoggingChunkSink - логирует чанки вместо сохранения (для отладки)
    - MultiChunkSink - рассылает чанки в несколько других ChunkSink (fan-out)
    - MetricsChunkSink - собирает статистику по чанкам, не сохраняя их

2. Логика batching и flush — не загрязняют VectorStore

3. Тестирование: легко подсунуть InMemoryChunkSink, не реализуя весь VectorStore

ChunkSink — НЕ замена IndexSink: IndexSink делает reconcile (idempotency +
upsert + refresh updated_at), а ChunkSink — просто batched raw upsert.
Используются для разных целей. Pipeline indexing идёт через IndexSink;
ChunkSink — для специфических case'ов вроде fan-out на несколько backend'ов
или log-only debug-трасс.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterable
from typing import Generic, TypeVar

from boba.indexing.chunks import Chunk
from boba.indexing.context import CollectionId, PipelineContext
from boba.indexing.vector_store import VectorStoreWriter
from boba.patterns import StreamSink

__all__ = ["ChunkSink", "VectorStoreChunkSink"]

T = TypeVar("T")


class ChunkSink(StreamSink[PipelineContext, Chunk[T]], ABC, Generic[T]):
    """
    Терминальный потребитель Chunk[T] в pipeline

    `handle(ctx, chunk)` — кладёт чанк в backend (с возможной буферизацией)
    `flush(ctx)` — сбрасывает буфер; обязан вызываться pipeline в конце
    """

    @abstractmethod
    def flush(self, ctx: PipelineContext) -> None:
        """Сбросить накопленный буфер в backend."""
        ...


class VectorStoreChunkSink(ChunkSink[T], Generic[T]):
    """
    ChunkSink, который батчит чанки до `batch_size` и автоматически flush'ит
    их через `VectorStoreWriter.upsert(collection, batch)`. Collection связан
    с sink'ом при конструировании — каждая VectorStoreChunkSink-инстанция
    пишет в одну фиксированную коллекцию.

    `flush(ctx)` вручную — для остатка буфера в конце прогона.

    Использует raw `VectorStoreWriter.upsert` без idempotency-check'а; для
    нормальной indexing-стороны лучше брать `IndexSink.reconcile`.
    """

    def __init__(
        self,
        store: VectorStoreWriter[T],
        collection: CollectionId,
        batch_size: int = 100,
    ) -> None:
        if batch_size < 1:
            raise ValueError(f"batch_size must be >= 1, got {batch_size}")

        self._store = store
        self._collection = collection
        self._batch_size = batch_size
        self._buffer: list[Chunk[T]] = []

    def name(self) -> str:
        return f"VectorStoreChunkSink(batch={self._batch_size})"

    def handle(self, ctx: PipelineContext, event: Chunk[T]) -> None:
        del ctx
        self._buffer.append(event)
        if len(self._buffer) >= self._batch_size:
            self._flush_batch(self._buffer)
            self._buffer = []

    def flush(self, ctx: PipelineContext) -> None:
        del ctx
        if self._buffer:
            self._flush_batch(self._buffer)
            self._buffer = []

    def _flush_batch(self, batch: Iterable[Chunk[T]]) -> None:
        self._store.upsert(self._collection, batch)
