from collections.abc import Mapping
from dataclasses import dataclass, field


@dataclass
class ViewErrorMessage:
    "Сообщение которое увидит пользователь в chainlit ui"

    content: str
    author: str = "Error"
    fail_on_persist_error: bool = False


@dataclass
class HttpErrorMessage:
    """
    Http сообщение для браузера.
    Полезно для spnego, когда нужно отправить ответ в виде:
        401 + WWW-Authenticate: Negotiate + пустое тело
        что заставит браузер сформировать spnego token и повторить запрос
        без участия пользователя в этом процессе
    """

    status_code: int
    content: str
    headers: Mapping[str, str] = field(default_factory=dict)


class BaseError(Exception):
    """
    базовый класс ошибок в приложении
    Если хочешь, что бы ошибка корректно отобразилась
    наследуйся от этого класса и определяй базовые методы
    """

    def view_message(self) -> ViewErrorMessage | None:
        "Возвращает соощение показываемое пользователю"
        return None

    def history_message(self) -> str | None:
        """
        Возвращает сообщение которое пишется в историю чата
        """
        return None

    def http_message(self) -> HttpErrorMessage | None:
        return None


class ExternalServiceError(BaseError):
    """
    Ошибка во внешнем сервисе (postgres, clickhouse, ldap, kerberos, etc...)
    Не наша вина.
    - view: показываем сообщение пользователю как есть
    - llm: показываем llm в историю такое же сообщение
    - log: записываем в log сообщение как есть
    """

    def __init__(
        self, service_name: str, message: str
    ):
        super().__init__(message)
        self.message = message
        self.service_name = service_name
        self.status_code = 503

    def view_message(self) -> ViewErrorMessage | None:
        return ViewErrorMessage(content=self.message)

    def http_message(self) -> HttpErrorMessage | None:
        return HttpErrorMessage(
            status_code=self.status_code,
            content=self.message,
        )

class InternalServiceError(BaseError):
    """
    Внутренняя ошибка (Например некорректная конфигурация)
    Наша вина, детали сообщения пользователю не показываем
    - view: показываем пользователю минимальное сообщение и уникальный код ошибки, который он может передать в поддержку
    - llm: не видит это сообщение
    - log: этот же код пишется в лог с максимально подробным сообщением, что бы программист смог разобраться в проблеме
    Сообщаем пользователю код, который он может отправить в поддержку
    Программист в логах сможет увидеть больше информации
    """  # noqa: E501

    def __init__(self, internal_detail: str, user_detail: str | None):
        super().__init__(internal_detail)
        # тех.описание только для лога, пользователь не видит
        self.internal_detail = internal_detail
        self.user_detail = user_detail
        self.status_code = 500

    def view_message(self) -> ViewErrorMessage | None:
        content = "Internal error"
        if self.user_detail:
            content += f"\n{self.user_detail}"

        return ViewErrorMessage(content)

    def http_message(self) -> HttpErrorMessage | None:
        return HttpErrorMessage(
            status_code=self.status_code,
            content=self.internal_detail,
        )

def to_domain(e: Exception) -> BaseError:
    "Заворачивает любое НЕ доменное исключение в InternalServiceError"
    if isinstance(e, BaseError):
        return e

    wrapped = InternalServiceError(
        internal_detail=str(e),
        user_detail=None,
    )
    # сохраняем оригинал, чтобы logging распечатал его traceback по цепочке:
    # у самого wrapped нет __traceback__ (его никто не raise-ил), а у e — есть
    wrapped.__cause__ = e
    return wrapped


class UserInputError(BaseError):
    """
    Пришли некорректные данные от пользователя (Например ошибка валидации по json-схеме)
    - view: показываем сообщение как есть
    - llm: не видит сообщение, ей это не нужно
    - log: сообщение не нужно, нет смысла логировать
    """

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message

    def view_message(self) -> ViewErrorMessage | None:
        return ViewErrorMessage(content=self.message)


class AuthenticationError(BaseError):
    """
    Не удалось аутентифицировать пользователя (Kerberos/LDAP/пароль)
    Возникает в HTTP-слое auth-callback (отдаётся как 401), а не в чате
    - view: показываем сообщение как есть
    - llm: не видит, до агента дело не дошло
    - log: warning без traceback, это ожидаемая ситуация
    """

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message
        self.status_code = 401

    def view_message(self) -> ViewErrorMessage | None:
        return ViewErrorMessage(content=self.message)

    def http_message(self) -> HttpErrorMessage | None:
        return HttpErrorMessage(
            status_code=self.status_code,
            content=self.message,
        )


class AuthorizationError(BaseError):
    """
    Аутентифицирован, но нет прав (нет нужной группы / доступа к инструменту)
    - view: показываем сообщение как есть
    - llm: видит — должен узнать, что инструмент/данные недоступны
    - log: warning без traceback
    """

    def __init__(self, message: str):
        super().__init__(message)
        self.message = message
        self.status_code = 403

    def view_message(self) -> ViewErrorMessage | None:
        return ViewErrorMessage(content=self.message)

class ToolExecutionError(BaseError):
    """
    Инструмент агента упал во время выполнения
    - view: пользователю не показываем, это внутренняя механика агента
    - llm: видит — должен переиграть (повторить / выбрать другой инструмент)
    - log: warning с traceback
    """

    def __init__(self, tool_name: str, message: str):
        super().__init__(message)
        self.message = message
        self.tool_name = tool_name

class RateLimitError(ExternalServiceError):
    """
    Превышен лимит запросов / квота внешнего провайдера (429)
    Частный случай ExternalServiceError: каналы те же (view/llm/log как есть)
    """

class AgentError(InternalServiceError):
    """
    Сломался сам граф/модель (не провайдер) — наша вина
    Частный случай InternalServiceError: пользователю код, llm не видит, детали в лог
    """
