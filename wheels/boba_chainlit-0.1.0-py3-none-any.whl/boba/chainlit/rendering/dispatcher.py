"""
Единый источник правды для маппинга AgentEvent -> UI-операции
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any, ClassVar, Protocol, assert_never

from boba.agent.events import (
    AdvisoryEvent,
    AgentEvent,
    AnswerDelta,
    AnswerMessage,
    DeltaEvent,
    DiagnosticEvent,
    FeedbackToLLMAdded,
    IterationStarted,
    MessageEvent,
    PhaseEvent,
    RefusalDelta,
    RefusalMessage,
    StreamKind,
    TerminalEvent,
    ThinkingDelta,
    ThinkingMessage,
    ToolCallDecodeFailedMessage,
    ToolCallDelta,
    ToolCallMessage,
    ToolExecutionFailed,
    ToolExecutionStarted,
    ToolResultReady,
    TotalMessage,
    UserQueryReceived,
)
from boba.chainlit.rendering.tool_result_view import (
    ChartRendering,
    MarkdownRendering,
    ToolResultView,
)
from boba.llm.events import FinishReason
from boba.tools.domain import ToolResult

__all__ = ["AgentEventDispatcher", "EventRenderTarget"]


class EventRenderTarget(Protocol):
    """Адаптер UI-операций. Реализация — chainlit-live или replay-StepDict."""

    # streaming (живой токен-стрим, replay no-op)

    async def answer_chunk(self, text: str) -> None: ...
    async def thinking_chunk(self, text: str) -> None: ...
    async def refusal_chunk(self, text: str) -> None: ...

    # завершения content-снапшотов

    async def user_query(self, text: str) -> None: ...
    async def answer_complete(self, text: str) -> None: ...
    async def answer_preamble(self, text: str) -> None: ...
    async def thinking_complete(self, text: str) -> None: ...
    async def refusal_complete(self, text: str) -> None: ...
    async def tool_result(
        self,
        call_id: str,
        text: str,
        *,
        is_error: bool,
    ) -> None: ...
    async def tool_chart(
        self,
        call_id: str,
        spec: Mapping[str, Any],
        title: str | None,
    ) -> None: ...
    async def feedback(self, text: str) -> None: ...

    # phase-маркеры (live UX, replay no-op)

    async def iteration_started(self) -> None: ...
    async def tool_started(
        self,
        call_id: str,
        name: str,
        args_json: str,
    ) -> None: ...
    async def generation_milestone(self) -> None: ...
    async def status(self, text: str) -> None: ...

    # ошибки и фатальные события

    async def tool_call_decode_failed(
        self,
        name: str,
        raw: str,
        error: str,
    ) -> None: ...
    async def tool_execution_failed(
        self,
        call_id: str,
        error_kind: str,
        message: str,
    ) -> None: ...
    async def advisory(self, headline: str, body: str) -> None: ...
    async def terminal(self, headline: str, body: str) -> None: ...

    # диагностика (telemetry; видна только при diagnostic-mode)

    async def diagnostic(self, event: DiagnosticEvent) -> None: ...


class AgentEventDispatcher:
    """Маппит каждый AgentEvent на ровно один вызов EventRenderTarget.

    Семантика категорий событий:
        DeltaEvent  — стриминг токенов (*_chunk); ToolCallDelta
                               игнорируется (UI рисует tool-step целиком
                               по tool_started, а не по чанкам args)
        MessageEvent — завершённый блок контента (*_complete,
                               user_query, tool_result, feedback);
                               ToolCallMessage — намерение LLM, в UI
                               не рендерится
        PhaseEvent         — состояния процесса (iteration_started,
                               tool_started — точка открытия tool-step'а
                               в UI, generation_milestone, status)
        AdvisoryEvent      — нефатальные ошибки (tool_call_decode_failed,
                               tool_execution_failed, advisory)
        TerminalEvent      — фатальное завершение (terminal)
        DiagnosticEvent    — телеметрия (diagnostic); решение «показывать
                               или нет» принимает target по своему toggle
    """

    _NS_PER_US: ClassVar[int] = 1_000
    _NS_PER_MS: ClassVar[int] = 1_000_000
    _NS_PER_S: ClassVar[int] = 1_000_000_000

    def __init__(self, target: EventRenderTarget) -> None:
        self._target = target

    async def handle(self, event: AgentEvent) -> None:  # noqa: C901, PLR0912
        # Порядок case'ов: сначала конкретные delta/snapshot/phase события,
        # потом fall-through на категории. У pydantic-discriminated unions
        # тип проверяется по полю type, поэтому конкретный case
        # сматчится раньше базового.
        match event:
            # ContentDelta
            case AnswerDelta():
                if event.chunk:
                    await self._target.answer_chunk(event.chunk)
            case ThinkingDelta():
                if event.chunk:
                    await self._target.thinking_chunk(event.chunk)
            case RefusalDelta():
                if event.chunk:
                    await self._target.refusal_chunk(event.chunk)
            case ToolCallDelta():
                # Tool args стримятся, но UI не открывает tool-step на
                # ToolCallMessage — он создаётся на ToolExecutionStarted,
                # где args уже доступны целиком. Делать no-op намеренно.
                return

            # --- ContentSnapshot --------------------------------------
            case UserQueryReceived(query=q):
                await self._target.user_query(q)
            case AnswerMessage():
                # НЕ коммитим ответ здесь: на AnswerMessage ещё не видно,
                # есть ли в этом turn'е tool_calls. Контент turn'а с
                # tool_calls — это преамбула (рисуем свёрнутым step'ом), без
                # tool_calls — финальный ответ (assistant-бабл). Решение
                # принимаем на TotalMessage (_commit_answer), где tool_calls
                # уже известны; иначе преамбула встаёт top-level баблом над
                # своими же tool-step'ами (лента упорядочена порядком вставки,
                # не created_at).
                return
            case ThinkingMessage(content=c):
                await self._target.thinking_complete(c)
            case RefusalMessage(content=c):
                await self._target.refusal_complete(c)
            case ToolCallMessage():
                # Намерение LLM вызвать tool — в UI не рендерим.
                # Видимый жизненный цикл step'а:
                # ToolExecutionStarted -> ToolResultReady|ToolExecutionFailed.
                return
            case ToolResultReady(call=call, result=result):
                await self._present_tool_result(call.id, result.result)
            case FeedbackToLLMAdded(content=c):
                await self._target.feedback(c)

            # PhaseEvent
            case IterationStarted():
                await self._target.iteration_started()
            case ToolExecutionStarted(call=call):
                await self._target.tool_started(
                    call.id,
                    call.name,
                    call.args_json(),
                )
            case TotalMessage():
                # терминатор генерации: гасим статус, коммитим ответ
                # (преамбула vs финал — по tool_calls), подсвечиваем исход
                await self._target.generation_milestone()
                await self._commit_answer(event)
                await self._handle_generation_completed(event)

            # AdvisoryEvent
            case ToolCallDecodeFailedMessage(failure=failure):
                await self._target.tool_call_decode_failed(
                    failure.name,
                    failure.raw,
                    failure.error,
                )
            case ToolExecutionFailed(call=call, failure=failure):
                await self._target.tool_execution_failed(
                    call.id,
                    failure.error_kind,
                    failure.message,
                )

            # DiagnosticEvent
            case DiagnosticEvent() as diagnostic_evt:
                # Target сам решает, показывать ли (по своему toggle).
                # Дополнительной специализации по type не делаем -
                # target фильтрует по topic.
                await self._target.diagnostic(diagnostic_evt)

            # Generic fall-throughs
            case MessageEvent() as snapshot:
                # Прочие snapshot'ы (например, USER_QUERY с не-UserQueryReceived
                # или TOOL_RESULT без ToolResultReady) — оставляем
                # последним fallback'ом, чтобы не потерять текст.
                await self._handle_unmatched_snapshot(snapshot)
            case PhaseEvent() as phase:
                await self._target.status(self._render_phase_text(phase))
            case AdvisoryEvent() as advisory:
                await self._target.advisory(
                    advisory.headline,
                    advisory.body or "",
                )
            case TerminalEvent() as terminal:
                await self._target.terminal(
                    terminal.headline,
                    terminal.body or "",
                )
            case DeltaEvent():
                # ContentDelta без специализации (StreamKind, который мы
                # не выделили выше) — игнорируем.
                return

    async def _present_tool_result(
        self,
        call_id: str,
        result: ToolResult,
    ) -> None:
        # Форму представления выбирает ToolResultView; здесь — только
        # диспетчеризация по ToolResultRendering (exhaustive, новый вид
        # представления потребует ветку). is_error=False: провал tool'а идёт
        # отдельным каналом (tool_execution_failed), не через ToolResultReady.
        match ToolResultView(result).render():
            case MarkdownRendering(markdown=markdown):
                await self._target.tool_result(call_id, markdown, is_error=False)
            case ChartRendering(spec=spec, title=title):
                await self._target.tool_chart(call_id, spec, title)
            case _ as never:
                assert_never(never)

    async def _commit_answer(self, event: TotalMessage) -> None:
        """Коммит текстового контента генерации на терминаторе turn'а.

        AnswerMessage сам по себе не рисуем: на нём ещё не виден tool_calls
        этого turn'а. Здесь tool_calls известны, поэтому различаем:

        - turn С tool_calls -> контент это преамбула (модель что-то сказала
          перед тем как пойти в инструмент) -> свёрнутый step, чтобы он не
          выглядел финальным ответом над своими же tool-step'ами;
        - turn БЕЗ tool_calls -> финальный ответ -> обычный assistant-бабл.

        Решение «финал = turn без tool_calls» совпадает с критерием остановки
        агентского цикла (StopIfReasonStop). refusal идёт отдельным каналом
        (message.refusal / RefusalMessage), content тут — только answer.
        """
        content = event.message.content or ""
        if not content.strip():
            return
        if event.message.tool_calls:
            await self._target.answer_preamble(content)
        else:
            await self._target.answer_complete(content)

    async def _handle_generation_completed(self, event: TotalMessage) -> None:
        """Подсветить «не-нормальный» исход генерации в UI.

        Для STOP / TOOL_CALLS — тихий no-op: per-field *Message события
        уже отрисовали контент, и TotalMessage несёт лишь агрегат,
        который без аномалии не нуждается в отдельной отрисовке.

        Для LENGTH — system-advisory: ответ обрезан, пользователь должен
        об этом узнать. Для CONTENT_FILTER — terminal: ответ заблокирован
        фильтром провайдера, повторение с тем же промптом обычно
        бесполезно.

        Тексты — на русском, как и весь UI Chainlit-агента; severity
        события уже выставлен по finish_reason в _derive.
        """
        match event.finish_reason:
            case FinishReason.LENGTH:
                body = self._fmt_outcome_body(event)
                await self._target.advisory(
                    "Ответ обрезан: достигнут лимит токенов",
                    body,
                )
            case FinishReason.CONTENT_FILTER:
                body = self._fmt_outcome_body(event)
                await self._target.terminal(
                    "Ответ заблокирован фильтром провайдера",
                    body,
                )
            case FinishReason.STOP | FinishReason.TOOL_CALLS:
                # Нормальный путь — контент уже отрисован per-field событиями.
                return

    @staticmethod
    def _fmt_outcome_body(event: TotalMessage) -> str:
        msg = event.message
        parts: list[str] = [f"finish_reason: {event.finish_reason.value}"]
        if msg.content:
            parts.append(f"answer length: {len(msg.content)} chars")
        if msg.thinking:
            parts.append(f"thinking length: {len(msg.thinking)} chars")
        if msg.tool_calls:
            parts.append(f"tool_calls: {len(msg.tool_calls)}")
        if msg.tool_call_decode_failures:
            n = len(msg.tool_call_decode_failures)
            parts.append(f"tool_call_decode_failures: {n}")
        return "\n".join(parts)

    async def _handle_unmatched_snapshot(
        self,
        event: MessageEvent,
    ) -> None:
        # На случай новых MessageEvent'ов, добавленных позже —
        # маршрутизируем по stream_kind, чтобы не молчать.
        if event.stream_kind == StreamKind.TOOL_RESULT:
            if event.stream_id:
                await self._target.tool_result(
                    event.stream_id,
                    event.body,
                    is_error=False,
                )
            return
        if event.stream_kind == StreamKind.FEEDBACK:
            await self._target.feedback(event.body)
            return
        # Остальные «неизвестные» снапшоты — best-effort через advisory,
        # чтобы текст не терялся в UI.
        if event.body:
            await self._target.advisory(
                event.headline or "snapshot",
                event.body,
            )

    @classmethod
    def _render_phase_text(cls, e: PhaseEvent) -> str:
        parts: list[str] = []
        if e.details:
            details = " ".join(f"{k}={v}" for k, v in e.details.items() if v)
            if details:
                parts.append(details)
        duration = cls._fmt_duration(e.duration_ns)
        if duration:
            parts.append(duration)
        if not parts:
            return e.label
        return f"{e.label} ({', '.join(parts)})"

    @classmethod
    def _fmt_duration(cls, ns: int) -> str:
        if ns <= 0:
            return ""
        if ns < cls._NS_PER_MS:
            return f"+{ns / cls._NS_PER_US:.0f}µs"
        if ns < cls._NS_PER_S:
            return f"+{ns / cls._NS_PER_MS:.0f}ms"
        return f"+{ns / cls._NS_PER_S:.2f}s"
