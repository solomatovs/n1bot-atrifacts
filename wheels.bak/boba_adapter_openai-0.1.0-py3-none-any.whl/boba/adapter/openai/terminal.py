"""Терминал LLM-слоя — обращение к OpenAI-совместимому API."""

from __future__ import annotations

import time
from collections.abc import Iterable, Iterator
from contextlib import contextmanager
from typing import Any

import httpx

import openai
from boba.adapter.openai.errors import OpenAIErrorConverter
from boba.adapter.openai.request import ToOpenAIRequestConverter
from boba.adapter.openai.response import FromOpenAIChunkConverter
from boba.domain.config import LLMConfig
from boba.domain.core.patterns import StreamSource
from boba.domain.llm.errors import LLMError
from boba.domain.llm.events import (
    LLMEvent,
    LLMRequestSent,
    LLMRequestStarted,
)
from boba.domain.llm.models import LLMContext
from boba.domain.llm.observer import LLMRequestObserver, RequestOutcome
from openai import OpenAI
from openai.types.chat.chat_completion_chunk import ChatCompletionChunk


def build_openai_client(config: LLMConfig) -> OpenAI:
    """Строит OpenAI-клиент из конфига."""
    return OpenAI(base_url=config.base_url, api_key=config.api_key)


@contextmanager
def _observe_request(
    observer: LLMRequestObserver[dict[str, Any], ChatCompletionChunk],
    kwargs: dict[str, Any],
) -> Iterator[None]:
    """Оборачивает тело стрима парой on_request / on_request_end."""

    observer.on_request(kwargs)
    try:
        yield
    except GeneratorExit:
        observer.on_request_end(RequestOutcome.cancelled())
        raise
    except BaseException as e:
        observer.on_request_end(RequestOutcome.raised(e))
        raise
    else:
        observer.on_request_end(RequestOutcome.ok())


class OpenAITerminal(StreamSource[LLMContext, LLMEvent]):
    """Terminal LLM-слоя, вызывающий OpenAI-совместимый API."""

    def __init__(
        self,
        client: OpenAI,
        observer: LLMRequestObserver[dict[str, Any], ChatCompletionChunk],
        *,
        reindex_tool_calls: bool = True,
    ) -> None:
        self._client = client
        self._to_request = ToOpenAIRequestConverter()
        self._error_converter = OpenAIErrorConverter()
        self._observer = observer
        self._reindex_tool_calls = reindex_tool_calls

    def name(self) -> str:
        return "OpenAITerminal"

    def stream(self, ctx: LLMContext) -> Iterable[LLMEvent]:
        kwargs = self._to_request.convert(ctx.request)

        with _observe_request(self._observer, kwargs):
            # Парные события вокруг HTTP-вызова: Started/Sent.
            yield LLMRequestStarted(
                request_id=ctx.request_id,
                model=ctx.request.model,
                messages_count=ctx.request.messages_count(),
                has_tools=ctx.request.has_tools(),
                monotonic_ns=time.monotonic_ns(),
            )

            # Классификация ошибок: Terminal (401/5xx) vs Retryable (лимиты).
            try:
                response = self._client.chat.completions.create(**kwargs)
            except LLMError:
                raise
            except (openai.APIError, httpx.HTTPError) as e:
                raise self._error_converter.convert(e) from e

            yield LLMRequestSent(
                request_id=ctx.request_id,
                monotonic_ns=time.monotonic_ns(),
            )

            try:
                yield from FromOpenAIChunkConverter(
                    ctx.request_id,
                    reindex_tool_calls=self._reindex_tool_calls,
                ).stream(ctx, self._observe_chunks(response))
            except LLMError:
                raise
            except (openai.APIError, httpx.HTTPError) as e:
                raise self._error_converter.convert(e) from e

    def _observe_chunks(
        self, chunks: Iterable[ChatCompletionChunk]
    ) -> Iterable[ChatCompletionChunk]:
        for chunk in chunks:
            self._observer.on_response_chunk(chunk)
            yield chunk
